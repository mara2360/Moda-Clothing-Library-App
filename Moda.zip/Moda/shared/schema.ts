import { pgTable, text, serial, integer, boolean, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { users } from "./models/auth";
import { relations } from "drizzle-orm";

export * from "./models/auth";

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  userId: varchar("user_id").notNull(), // Links to auth users
});

export const items = pgTable("items", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  title: text("title").notNull(),
  productName: text("product_name"),
  companyName: text("company_name"),
  price: text("price"),
  imageUrl: text("image_url"),
  categoryId: integer("category_id").references(() => categories.id),
  userId: varchar("user_id").notNull(), // Links to auth users
  isBought: boolean("is_bought").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const categoriesRelations = relations(categories, ({ one, many }) => ({
  user: one(users, {
    fields: [categories.userId],
    references: [users.id],
  }),
  items: many(items),
}));

export const itemsRelations = relations(items, ({ one }) => ({
  category: one(categories, {
    fields: [items.categoryId],
    references: [categories.id],
  }),
  user: one(users, {
    fields: [items.userId],
    references: [users.id],
  }),
}));

// Insert Schemas
export const insertCategorySchema = createInsertSchema(categories).omit({ id: true });
export const insertItemSchema = createInsertSchema(items).omit({ id: true, createdAt: true, isBought: true });

// Types
export type Category = typeof categories.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Item = typeof items.$inferSelect;
export type InsertItem = z.infer<typeof insertItemSchema>;
