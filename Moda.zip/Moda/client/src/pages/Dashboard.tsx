import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useItems } from "@/hooks/use-items";
import { useCategories, useDeleteCategory } from "@/hooks/use-categories";
import { ItemCard } from "@/components/ItemCard";
import { AddItemDialog } from "@/components/AddItemDialog";
import { CreateCategoryDialog } from "@/components/CreateCategoryDialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { 
  LayoutGrid, 
  Menu, 
  LogOut, 
  Trash2,
  Search,
  ShoppingBag
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Redirect } from "wouter";

export default function Dashboard() {
  const { user, logout, isLoading: authLoading } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>(undefined);
  const [searchQuery, setSearchQuery] = useState("");
  
  const { data: categories } = useCategories();
  const { data: items, isLoading: itemsLoading } = useItems(selectedCategory);
  const { mutate: deleteCategory } = useDeleteCategory();

  if (authLoading) return null;
  if (!user) return <Redirect to="/auth" />;

  const filteredItems = items?.filter(item => 
    item.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleDeleteCategory = (e: React.MouseEvent, id: number) => {
    e.stopPropagation();
    if (confirm("Delete this category? Items will remain but lose their category.")) {
      deleteCategory(id);
      if (selectedCategory === id.toString()) {
        setSelectedCategory(undefined);
      }
    }
  };

  const SidebarContent = () => (
    <div className="flex h-full flex-col gap-6">
      <div className="flex items-center gap-3 px-2">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-lg shadow-primary/20">
          <ShoppingBag className="h-5 w-5" />
        </div>
        <span className="font-display text-xl font-bold">Wishlist</span>
      </div>

      <div className="space-y-4 flex-1">
        <div className="space-y-1">
          <h4 className="px-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground/70">
            Browse
          </h4>
          <Button
            variant={!selectedCategory ? "secondary" : "ghost"}
            className="w-full justify-start gap-3 font-medium"
            onClick={() => setSelectedCategory(undefined)}
          >
            <LayoutGrid className="h-4 w-4" />
            All Items
          </Button>
        </div>

        <div className="space-y-1">
          <div className="flex items-center justify-between px-2 py-2">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground/70">
              Collections
            </h4>
          </div>
          <ScrollArea className="h-[300px] pr-2">
            <div className="space-y-1">
              {categories?.map((category) => (
                <div key={category.id} className="group relative flex items-center">
                  <Button
                    variant={selectedCategory === category.id.toString() ? "secondary" : "ghost"}
                    className="w-full justify-start truncate pr-10"
                    onClick={() => setSelectedCategory(category.id.toString())}
                  >
                    {category.name}
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="absolute right-1 h-7 w-7 opacity-0 transition-opacity group-hover:opacity-100 hover:bg-destructive/10 hover:text-destructive"
                    onClick={(e) => handleDeleteCategory(e, category.id)}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              ))}
              <CreateCategoryDialog />
            </div>
          </ScrollArea>
        </div>
      </div>

      <div className="border-t border-border/50 pt-4">
        <div className="flex items-center gap-3 px-2 py-3 mb-2 rounded-lg bg-secondary/30">
          {user.profileImageUrl ? (
            <img src={user.profileImageUrl} alt="Profile" className="h-8 w-8 rounded-full bg-white" />
          ) : (
            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs">
              {user.firstName?.[0] || user.email?.[0]}
            </div>
          )}
          <div className="flex-1 overflow-hidden">
            <p className="truncate text-sm font-medium">{user.firstName || 'User'}</p>
            <p className="truncate text-xs text-muted-foreground">{user.email}</p>
          </div>
        </div>
        <Button variant="outline" className="w-full justify-start gap-2" onClick={() => logout()}>
          <LogOut className="h-4 w-4" />
          Sign out
        </Button>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-background text-foreground">
      {/* Desktop Sidebar */}
      <aside className="hidden w-64 border-r border-border/40 bg-card/50 p-6 backdrop-blur-sm lg:block fixed inset-y-0">
        <SidebarContent />
      </aside>

      {/* Main Content */}
      <main className="flex-1 lg:pl-64">
        <div className="container mx-auto max-w-7xl px-4 py-8 md:px-8">
          {/* Header */}
          <header className="mb-8 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div className="flex items-center gap-4">
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" size="icon" className="lg:hidden">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-72">
                  <SidebarContent />
                </SheetContent>
              </Sheet>
              
              <div>
                <h1 className="font-display text-3xl font-bold">
                  {selectedCategory 
                    ? categories?.find(c => c.id.toString() === selectedCategory)?.name 
                    : "My Wishlist"}
                </h1>
                <p className="text-muted-foreground mt-1">
                  {filteredItems?.length || 0} items collected
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4 w-full md:w-auto">
              <div className="relative flex-1 md:w-64">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input 
                  placeholder="Search items..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 bg-card border-border/50 rounded-full" 
                />
              </div>
              <div className="hidden md:block">
                <AddItemDialog />
              </div>
            </div>
          </header>

          {/* Items Grid */}
          {itemsLoading ? (
            <div className="grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-4">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="aspect-[4/5] rounded-xl bg-muted/30 animate-pulse" />
              ))}
            </div>
          ) : filteredItems?.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <div className="mb-4 rounded-full bg-secondary/50 p-6 text-muted-foreground">
                <ShoppingBag className="h-10 w-10" />
              </div>
              <h3 className="mb-2 font-display text-xl font-semibold">No items found</h3>
              <p className="mb-6 max-w-sm text-muted-foreground">
                {searchQuery 
                  ? "Try adjusting your search terms." 
                  : "Start building your collection by adding your first item."}
              </p>
              <AddItemDialog />
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 md:gap-x-6 lg:grid-cols-4 xl:grid-cols-5">
              {filteredItems?.map((item) => (
                <ItemCard 
                  key={item.id} 
                  item={item} 
                  category={categories?.find(c => c.id === item.categoryId)} 
                />
              ))}
            </div>
          )}
        </div>
        
        {/* Mobile FAB */}
        <div className="fixed bottom-6 right-6 md:hidden">
          <AddItemDialog />
        </div>
      </main>
    </div>
  );
}
