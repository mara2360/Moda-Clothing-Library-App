import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, ShoppingBag, Sparkles } from "lucide-react";

export default function AuthPage() {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="animate-pulse flex flex-col items-center gap-4">
          <div className="h-12 w-12 rounded-full bg-muted"></div>
          <div className="h-4 w-32 rounded bg-muted"></div>
        </div>
      </div>
    );
  }

  if (user) {
    return <Redirect to="/" />;
  }

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      {/* Left Panel - Hero */}
      <div className="relative hidden lg:flex flex-col justify-between bg-primary p-12 text-primary-foreground overflow-hidden">
        {/* Abstract shapes/background */}
        <div className="absolute top-0 right-0 -mr-32 -mt-32 h-[500px] w-[500px] rounded-full bg-white/5 blur-3xl"></div>
        <div className="absolute bottom-0 left-0 -ml-32 -mb-32 h-[500px] w-[500px] rounded-full bg-white/5 blur-3xl"></div>
        
        {/* Unsplash image background */}
        <div className="absolute inset-0 z-0 opacity-20 mix-blend-overlay">
          {/* Fashion aesthetic studio shot */}
          <img 
            src="https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&q=80&w=2070" 
            alt="Fashion Background" 
            className="h-full w-full object-cover"
          />
        </div>

        <div className="relative z-10">
          <div className="flex items-center gap-2 text-2xl font-display font-bold">
            <ShoppingBag className="h-8 w-8" />
            <span>Wishlist</span>
          </div>
        </div>

        <div className="relative z-10 max-w-lg space-y-6">
          <h1 className="font-display text-5xl font-bold leading-tight">
            Curate your dream wardrobe.
          </h1>
          <p className="text-lg text-primary-foreground/80 font-light leading-relaxed">
            Save items from any store, organize them into collections, and track what you've bought. Ideally simple, beautifully organized.
          </p>
        </div>

        <div className="relative z-10 text-sm opacity-60">
          © {new Date().getFullYear()} Wishlist App
        </div>
      </div>

      {/* Right Panel - Login Form */}
      <div className="flex flex-col items-center justify-center p-8 sm:p-12 bg-background">
        <Card className="w-full max-w-md border-none shadow-none bg-transparent">
          <div className="mb-8 text-center space-y-2">
            <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/5 text-primary">
              <Sparkles className="h-8 w-8" />
            </div>
            <h2 className="font-display text-3xl font-bold tracking-tight">Welcome back</h2>
            <p className="text-muted-foreground">Sign in to access your collections</p>
          </div>

          <div className="space-y-4">
            <Button 
              className="w-full h-12 text-base rounded-xl font-medium shadow-lg shadow-primary/10 transition-all hover:scale-[1.02] hover:shadow-xl" 
              onClick={() => window.location.href = "/api/login"}
            >
              Continue with Replit
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            
            <p className="text-center text-sm text-muted-foreground pt-4">
              By clicking continue, you agree to our Terms of Service and Privacy Policy.
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
}
