import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useCreateItem } from "@/hooks/use-items";
import { useCategories } from "@/hooks/use-categories";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Loader2 } from "lucide-react";
import { useState, useEffect } from "react";
import { insertItemSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

import { ObjectUploader } from "./ObjectUploader";
import { useUpload } from "@/hooks/use-upload";

const formSchema = insertItemSchema.omit({ userId: true, createdAt: true, isBought: true }).extend({
  url: z.string().url("Please enter a valid product URL"),
  title: z.string().min(1, "Wishlist title is required"),
  categoryId: z.number().optional().nullable(),
  productName: z.string().optional().nullable(),
  companyName: z.string().optional().nullable(),
  price: z.string().optional().nullable(),
  imageUrl: z.string().optional().nullable(),
});

export function AddItemDialog() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState<"url" | "details">("url");
  const [isScraping, setIsScraping] = useState(false);
  const { mutate, isPending } = useCreateItem();
  const { data: categories } = useCategories();
  const { toast } = useToast();
  const { getUploadParameters } = useUpload();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      productName: "",
      companyName: "",
      price: "",
      url: "",
      imageUrl: "",
    },
  });

  const urlValue = form.watch("url");

  const handleNext = async () => {
    if (!urlValue || !urlValue.startsWith("http")) {
      form.setError("url", { message: "Please enter a valid product URL" });
      return;
    }

    setIsScraping(true);
    try {
      const response = await fetch("/api/metadata", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: urlValue }),
        credentials: "include",
      });

      if (response.ok) {
        const data = await response.json();
        if (data.productName) {
          form.setValue("title", data.productName);
          form.setValue("productName", data.productName);
        } else if (data.title) {
          form.setValue("title", data.title);
        }
        if (data.companyName) form.setValue("companyName", data.companyName);
        if (data.price) form.setValue("price", data.price);
        if (data.image) form.setValue("imageUrl", data.image);
        setStep("details");
      } else {
        toast({
          title: "Error",
          description: "Could not fetch product details. You can enter them manually.",
          variant: "destructive",
        });
        setStep("details");
      }
    } catch (error) {
      setStep("details");
    } finally {
      setIsScraping(false);
    }
  };

  function onSubmit(values: z.infer<typeof formSchema>) {
    console.log("Submitting values:", values);
    mutate(values, {
      onSuccess: () => {
        setOpen(false);
        setStep("url");
        form.reset();
      },
      onError: (error) => {
        console.error("Mutation error:", error);
      }
    });
  }

  const handleOpenChange = (newOpen: boolean) => {
    setOpen(newOpen);
    if (!newOpen) {
      setStep("url");
      form.reset();
    }
  };

  // Log form errors for debugging
  useEffect(() => {
    if (Object.keys(form.formState.errors).length > 0) {
      console.log("Form validation errors:", form.formState.errors);
    }
  }, [form.formState.errors]);

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <Button size="lg" className="rounded-full shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 transition-all duration-300 font-semibold px-6">
          <Plus className="mr-2 h-5 w-5" />
          Add Item
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] rounded-xl border-border/50 shadow-2xl">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">
            {step === "url" ? "Enter Product Link" : "Confirm Details"}
          </DialogTitle>
          <DialogDescription>
            {step === "url" 
              ? "Paste the URL of the clothing item you want to save." 
              : "We've fetched the details for you. Feel free to edit them."}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5 pt-4">
            {step === "url" ? (
              <>
                <FormField
                  control={form.control}
                  name="url"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Product URL</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="https://store.com/item..." 
                          {...field} 
                          className="rounded-lg border-border/50 bg-secondary/20" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex justify-end pt-2">
                  <Button 
                    type="button" 
                    onClick={handleNext} 
                    disabled={isScraping}
                    className="rounded-lg min-w-[120px]"
                  >
                    {isScraping ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Fetching...
                      </>
                    ) : (
                      "Next"
                    )}
                  </Button>
                </div>
              </>
            ) : (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="productName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Product Name</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="e.g. Leather Boots" 
                            {...field} 
                            value={field.value || ""} 
                            className="rounded-lg border-border/50 bg-secondary/20" 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="companyName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Company Name</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="e.g. Nike" 
                            {...field} 
                            value={field.value || ""} 
                            className="rounded-lg border-border/50 bg-secondary/20" 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="price"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Price</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. $99.99" {...field} value={field.value || ""} className="rounded-lg border-border/50 bg-secondary/20" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="categoryId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Category (Optional)</FormLabel>
                        <Select onValueChange={(val) => field.onChange(val ? Number(val) : undefined)} value={field.value?.toString()}>
                          <FormControl>
                            <SelectTrigger className="rounded-lg border-border/50 bg-secondary/20">
                              <SelectValue placeholder="Select collection" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {categories?.map((cat) => (
                              <SelectItem key={cat.id} value={cat.id.toString()}>
                                {cat.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="imageUrl"
                  render={({ field }) => (
                    <FormItem>
                      <div className="flex justify-between items-center mb-2">
                        <FormLabel>Image URL (Optional)</FormLabel>
                        <ObjectUploader
                          onGetUploadParameters={getUploadParameters}
                          onComplete={(result) => {
                            if (result.successful?.[0]) {
                              // Correctly map the path from the uploadURL or result
                              const urlStr = result.successful[0].uploadURL as string;
                              const objectPath = `/objects/uploads/${urlStr.split('?')[0].split('/').pop()}`;
                              form.setValue("imageUrl", objectPath);
                              toast({
                                title: "Upload successful",
                                description: "Image has been uploaded and linked.",
                              });
                            }
                          }}
                          buttonClassName="h-7 text-xs px-2"
                        >
                          Upload from Phone
                        </ObjectUploader>
                      </div>
                      <FormControl>
                        <Input 
                          placeholder="https://..." 
                          {...field} 
                          value={field.value || ''} 
                          className="rounded-lg border-border/50 bg-secondary/20" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-between pt-2">
                  <Button type="button" variant="ghost" onClick={() => setStep("url")} className="rounded-lg">
                    Back
                  </Button>
                  <div className="flex gap-3">
                    <Button type="button" variant="outline" onClick={() => setOpen(false)} className="rounded-lg">
                      Cancel
                    </Button>
                    <Button type="submit" disabled={isPending} className="rounded-lg min-w-[120px]">
                      {isPending ? "Adding..." : "Add to Wishlist"}
                    </Button>
                  </div>
                </div>
              </>
            )}
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
