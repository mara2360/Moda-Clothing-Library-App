import { motion } from "framer-motion";
import { Item, Category } from "@shared/schema";
import { useDeleteItem, useUpdateItem } from "@/hooks/use-items";
import { cn } from "@/lib/utils";
import { 
  Trash2, 
  ExternalLink, 
  CheckCircle2, 
  Circle,
  ShoppingBag
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface ItemCardProps {
  item: Item;
  category?: Category;
}

export function ItemCard({ item, category }: ItemCardProps) {
  const { mutate: deleteItem, isPending: isDeleting } = useDeleteItem();
  const { mutate: updateItem, isPending: isUpdating } = useUpdateItem();

  const handleToggleBought = () => {
    updateItem({ id: item.id, isBought: !item.isBought });
  };

  const handleDelete = () => {
    if (confirm("Are you sure you want to delete this item?")) {
      deleteItem(item.id);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      layout
      className={cn(
        "group relative flex flex-col overflow-hidden rounded-xl bg-card border border-border/40 transition-all duration-300 hover:shadow-lg hover:-translate-y-1",
        item.isBought && "bg-muted/30 opacity-75 hover:opacity-100"
      )}
    >
      {/* Image Area */}
      <div className="relative aspect-[4/5] overflow-hidden bg-secondary/30">
        {item.imageUrl ? (
          <img
            src={item.imageUrl}
            alt={item.title}
            className={cn(
              "h-full w-full object-cover transition-transform duration-500 group-hover:scale-105",
              item.isBought && "grayscale-[50%]"
            )}
            onError={(e) => {
              e.currentTarget.style.display = 'none';
              e.currentTarget.parentElement?.classList.add('flex', 'items-center', 'justify-center');
            }}
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-muted-foreground/30">
            <ShoppingBag className="h-16 w-16" />
          </div>
        )}

        {/* Bought Overlay Badge */}
        {item.isBought && (
          <div className="absolute inset-0 z-10 flex items-center justify-center bg-black/10 backdrop-blur-[1px]">
            <Badge className="bg-green-600 hover:bg-green-700 text-white border-none px-4 py-1.5 text-sm shadow-lg font-medium tracking-wide">
              BOUGHT
            </Badge>
          </div>
        )}

        {/* Hover Actions Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100 flex flex-col justify-end p-4">
          <div className="flex items-center justify-between gap-2">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  size="icon"
                  variant="secondary"
                  className={cn(
                    "h-9 w-9 rounded-full bg-white/90 hover:bg-white text-foreground shadow-sm backdrop-blur-sm transition-colors",
                    item.isBought ? "text-green-600 hover:text-green-700" : "text-muted-foreground hover:text-primary"
                  )}
                  onClick={handleToggleBought}
                  disabled={isUpdating}
                >
                  {item.isBought ? <CheckCircle2 className="h-4 w-4" /> : <Circle className="h-4 w-4" />}
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                {item.isBought ? "Mark as wanted" : "Mark as bought"}
              </TooltipContent>
            </Tooltip>

            <div className="flex gap-2">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    size="icon"
                    variant="destructive"
                    className="h-9 w-9 rounded-full opacity-80 hover:opacity-100 shadow-sm"
                    onClick={handleDelete}
                    disabled={isDeleting}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Delete item</TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <a
                    href={item.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-white/90 hover:bg-white text-foreground shadow-sm backdrop-blur-sm transition-colors"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </TooltipTrigger>
                <TooltipContent>Visit Store</TooltipContent>
              </Tooltip>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex flex-col gap-2 p-4">
        <div className="flex items-start justify-between gap-2">
          {category && (
            <Badge variant="outline" className="w-fit rounded-full border-border/50 bg-secondary/30 px-2.5 py-0.5 text-xs font-normal text-muted-foreground">
              {category.name}
            </Badge>
          )}
          {item.price && (
            <span className="text-sm font-semibold text-primary">
              {item.price}
            </span>
          )}
        </div>
        
        <div className="flex flex-col gap-0.5">
          {item.companyName && (
            <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground/70">
              {item.companyName}
            </span>
          )}
          <h3 className={cn(
            "font-display text-lg leading-tight line-clamp-2",
            item.isBought && "text-muted-foreground line-through decoration-border"
          )}>
            {item.productName || item.title}
          </h3>
        </div>
      </div>
    </motion.div>
  );
}
