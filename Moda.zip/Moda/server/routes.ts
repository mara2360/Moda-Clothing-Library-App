import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes, isAuthenticated } from "./replit_integrations/auth";
import * as cheerio from "cheerio";
import fetch from "node-fetch";

import { registerObjectStorageRoutes } from "./replit_integrations/object_storage";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Set up authentication FIRST
  await setupAuth(app);
  registerAuthRoutes(app);
  registerObjectStorageRoutes(app);

  app.post("/api/metadata", isAuthenticated, async (req, res) => {
    try {
      const { url } = z.object({ url: z.string().url() }).parse(req.body);

      const response = await fetch(url, {
        redirect: "follow",
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
          "Accept":
            "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
          "Accept-Language": "en-US,en;q=0.9",
          "Cache-Control": "no-cache",
          "Pragma": "no-cache",
        },
      });

      const html = await response.text();
      const $ = cheerio.load(html);

      const title =
        $('meta[property="og:title"]').attr("content") ||
        $('meta[name="twitter:title"]').attr("content") ||
        $("title").text() ||
        "";

      const companyName = 
        $('meta[property="og:site_name"]').attr("content") || 
        $('meta[name="twitter:site"]').attr("content") ||
        "";

      const price = 
        $('meta[property="product:price:amount"]').attr("content") ||
        $('meta[property="og:price:amount"]').attr("content") ||
        "";

      const blockedTitles = ["access denied", "attention required", "robot check"];
      if (blockedTitles.includes(title.toLowerCase())) {
        return res.json({ title: "", image: "", companyName: "", productName: "", price: "" });
      }

      let image =
        $('meta[property="og:image"]').attr("content") ||
        $('meta[name="twitter:image"]').attr("content") ||
        "";

      // Handle relative image URLs
      if (image && image.startsWith("/")) {
        const parsedUrl = new URL(url);
        image = `${parsedUrl.origin}${image}`;
      }

      // Best-effort image fallback
      if (!image) {
        image = $("img").first().attr("src") || "";
        if (image && image.startsWith("/")) {
          const parsedUrl = new URL(url);
          image = `${parsedUrl.origin}${image}`;
        }
      }

      res.json({ title, image, companyName, productName: title, price });
    } catch (error) {
      console.error(error);
      res.status(400).json({ message: "Failed to fetch metadata" });
    }
  });

  // Categories API
  app.get(api.categories.list.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const categories = await storage.getCategories(userId);
    res.json(categories);
  });

  app.post(api.categories.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.categories.create.input.parse(req.body);
      const userId = req.user.claims.sub;
      const category = await storage.createCategory({ ...input, userId });
      res.status(201).json(category);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.delete(api.categories.delete.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const id = parseInt(req.params.id);
    await storage.deleteCategory(id, userId);
    res.status(204).send();
  });

  // Items API
  app.get(api.items.list.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const categoryId = req.query.categoryId ? parseInt(req.query.categoryId as string) : undefined;
    const items = await storage.getItems(userId, categoryId);
    res.json(items);
  });

  app.post(api.items.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.items.create.input.parse(req.body);
      const userId = req.user.claims.sub;
      const item = await storage.createItem({ ...input, userId });
      res.status(201).json(item);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.patch(api.items.update.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const id = parseInt(req.params.id);
    try {
      const input = api.items.update.input.parse(req.body);
      const item = await storage.updateItem(id, userId, input);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      res.json(item);
    } catch (err) {
       if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.delete(api.items.delete.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const id = parseInt(req.params.id);
    await storage.deleteItem(id, userId);
    res.status(204).send();
  });

  return httpServer;
}
