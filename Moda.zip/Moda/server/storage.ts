import { db } from "./db";
import {
  categories,
  items,
  type InsertCategory,
  type InsertItem,
  type Category,
  type Item,
} from "@shared/schema";
import { eq, and, desc } from "drizzle-orm";
import { authStorage, type IAuthStorage } from "./replit_integrations/auth/storage";

export interface IStorage extends IAuthStorage {
  getCategories(userId: string): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  deleteCategory(id: number, userId: string): Promise<void>;

  getItems(userId: string, categoryId?: number): Promise<Item[]>;
  getItem(id: number): Promise<Item | undefined>;
  createItem(item: InsertItem): Promise<Item>;
  updateItem(id: number, userId: string, updates: Partial<Item>): Promise<Item | undefined>;
  deleteItem(id: number, userId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // Auth methods delegated to the imported authStorage
  getUser = authStorage.getUser;
  upsertUser = authStorage.upsertUser;

  async getCategories(userId: string): Promise<Category[]> {
    return await db
      .select()
      .from(categories)
      .where(eq(categories.userId, userId));
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db
      .insert(categories)
      .values(category)
      .returning();
    return newCategory;
  }

  async deleteCategory(id: number, userId: string): Promise<void> {
    await db
      .delete(categories)
      .where(and(eq(categories.id, id), eq(categories.userId, userId)));
  }

  async getItems(userId: string, categoryId?: number): Promise<Item[]> {
    if (categoryId) {
      return await db
        .select()
        .from(items)
        .where(and(eq(items.userId, userId), eq(items.categoryId, categoryId)))
        .orderBy(desc(items.createdAt));
    }
    return await db
      .select()
      .from(items)
      .where(eq(items.userId, userId))
      .orderBy(desc(items.createdAt));
  }

  async getItem(id: number): Promise<Item | undefined> {
    const [item] = await db.select().from(items).where(eq(items.id, id));
    return item;
  }

  async createItem(item: InsertItem): Promise<Item> {
    const [newItem] = await db.insert(items).values(item).returning();
    return newItem;
  }

  async updateItem(id: number, userId: string, updates: Partial<Item>): Promise<Item | undefined> {
    const [updated] = await db
      .update(items)
      .set(updates)
      .where(and(eq(items.id, id), eq(items.userId, userId)))
      .returning();
    return updated;
  }

  async deleteItem(id: number, userId: string): Promise<void> {
    await db
      .delete(items)
      .where(and(eq(items.id, id), eq(items.userId, userId)));
  }
}

export const storage = new DatabaseStorage();
